/* -*- c++ -*- */
/*
 * Copyright 2025 you.
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

#ifndef INCLUDED_ALLOCATORCPP_ALLOCATORCPP_IMPL_H
#define INCLUDED_ALLOCATORCPP_ALLOCATORCPP_IMPL_H

#include <gnuradio/allocatorcpp/Allocatorcpp.h>
#include <deque>
#include <vector>
#include <complex>

namespace gr {
namespace allocatorcpp {

class Allocatorcpp_impl : public Allocatorcpp
{
private:
    int d_mask_len;
    std::deque<std::complex<float>> d_data_buffer;
    std::deque<std::vector<float>> d_mask_buffer;

public:
    Allocatorcpp_impl(int mask_len);
    ~Allocatorcpp_impl();

    int work(int noutput_items,
             gr_vector_const_void_star& input_items,
             gr_vector_void_star& output_items) override;
};

} // namespace allocatorcpp
} // namespace gr

#endif /* INCLUDED_ALLOCATORCPP_ALLOCATORCPP_IMPL_H */

