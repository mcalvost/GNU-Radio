/* -*- c++ -*- */
/*
 * Copyright 2025 you.
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 */
#include "Allocatorcpp_impl.h"
#include <gnuradio/io_signature.h>
#include <deque>
#include <vector>
#include <algorithm>
#include <cstring>

namespace gr {
namespace allocatorcpp {

using input_type_data = std::complex<float>;
using input_type_mask = float;
using output_type = std::complex<float>;

Allocatorcpp::sptr Allocatorcpp::make(int mask_len)
{
    return gnuradio::make_block_sptr<Allocatorcpp_impl>(mask_len);
}

Allocatorcpp_impl::Allocatorcpp_impl(int mask_len)
    : gr::sync_block("Allocatorcpp",
                     gr::io_signature::make2(2, 2,
                         sizeof(input_type_data),                    // in 0: complex data
                         sizeof(input_type_mask) * mask_len),        // in 1: mask
                     gr::io_signature::make(
                         1, 1,
                         sizeof(output_type) * mask_len)),           // out: OFDM symbol
      d_mask_len(mask_len)
{
}

Allocatorcpp_impl::~Allocatorcpp_impl() {}

int Allocatorcpp_impl::work(int noutput_items,
                            gr_vector_const_void_star& input_items,
                            gr_vector_void_star& output_items)
{
    const input_type_data* in_data = static_cast<const input_type_data*>(input_items[0]);
    const input_type_mask* in_mask = static_cast<const input_type_mask*>(input_items[1]);
    output_type* out = static_cast<output_type*>(output_items[0]);

    int symbols_written = 0;

    // Add new data to the buffer efficiently
    d_data_buffer.insert(d_data_buffer.end(), in_data, in_data + noutput_items * d_mask_len);

    // Add new masks to the buffer
    for (int i = 0; i < noutput_items; ++i) {
        std::vector<float> mask(in_mask + i * d_mask_len, in_mask + (i + 1) * d_mask_len);
        d_mask_buffer.emplace_back(std::move(mask));
    }

    // Process OFDM symbols
    for (int i = 0; i < noutput_items; ++i) {
        if (d_mask_buffer.empty()) break;

        const std::vector<float>& mask = d_mask_buffer.front();

        std::vector<int> occupied_carriers;
        occupied_carriers.reserve(d_mask_len);  
        for (int j = 0; j < d_mask_len; ++j) {
            if (mask[j] < 0.5f) {
                occupied_carriers.push_back(j);
            }
        }

        int num_occupied = occupied_carriers.size();
        if (d_data_buffer.size() < static_cast<size_t>(num_occupied)) break;

        std::vector<std::complex<float>> ofdm_symbol(d_mask_len, {0.0f, 0.0f});
        for (int k = 0; k < num_occupied; ++k) {
            ofdm_symbol[occupied_carriers[k]] = d_data_buffer[k];
        }

        std::memcpy(out + i * d_mask_len, ofdm_symbol.data(), d_mask_len * sizeof(std::complex<float>));

        // Remove used data
        d_data_buffer.erase(d_data_buffer.begin(), d_data_buffer.begin() + num_occupied);
        d_mask_buffer.pop_front();

        symbols_written++;
    }

    return symbols_written;
}



} // namespace allocatorcpp
} // namespace gr


