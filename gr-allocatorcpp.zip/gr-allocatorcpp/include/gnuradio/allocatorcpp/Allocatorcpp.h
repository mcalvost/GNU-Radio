/* -*- c++ -*- */
/*
 * Copyright 2025 you.
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

#ifndef INCLUDED_ALLOCATORCPP_ALLOCATORCPP_H
#define INCLUDED_ALLOCATORCPP_ALLOCATORCPP_H

#include <gnuradio/allocatorcpp/api.h>
#include <gnuradio/sync_block.h>

namespace gr {
namespace allocatorcpp {

/*!
 * \brief <+description of block+>
 * \ingroup allocatorcpp
 *
 */
class ALLOCATORCPP_API Allocatorcpp : virtual public gr::sync_block
{
public:
    typedef std::shared_ptr<Allocatorcpp> sptr;

    /*!
     * \brief Return a shared_ptr to a new instance of allocatorcpp::Allocatorcpp.
     *
     * To avoid accidental use of raw pointers, allocatorcpp::Allocatorcpp's
     * constructor is in a private implementation
     * class. allocatorcpp::Allocatorcpp::make is the public interface for
     * creating new instances.
     */
    static sptr make(int mask_len);
};

} // namespace allocatorcpp
} // namespace gr

#endif /* INCLUDED_ALLOCATORCPP_ALLOCATORCPP_H */
