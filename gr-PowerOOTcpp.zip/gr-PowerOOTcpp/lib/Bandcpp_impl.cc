/* -*- c++ -*- */
/*
 * Copyright 2025 you.
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

#include "Bandcpp_impl.h"
#include <gnuradio/io_signature.h>
#include <cmath>
#include <complex>
#include <vector>
#include <numeric>
#include <stdexcept>

namespace gr {
namespace PowerOOTcpp {

using input_type = std::complex<float>;
using output_type = float;


Bandcpp::sptr Bandcpp::make(int num_subbands, int fft_len)
{
	return gnuradio::make_block_sptr<Bandcpp_impl>(num_subbands, fft_len);
}

// Constructor
Bandcpp_impl::Bandcpp_impl(int num_subbands, int fft_len)
	: gr::sync_block("Bandcpp",
                 	gr::io_signature::make(1, 1, sizeof(std::complex<float>) * fft_len),
                 	gr::io_signature::make(1, 1, sizeof(float) * num_subbands)),
  	d_num_subbands(num_subbands),
  	d_fft_len(fft_len),
  	d_subband_size(fft_len / num_subbands)
{
	if (fft_len % num_subbands != 0)
		throw std::runtime_error("fft_len must be divisible by num_subbands");
}

// Destructor
Bandcpp_impl::~Bandcpp_impl() {}

int Bandcpp_impl::work(int noutput_items,
                   	gr_vector_const_void_star& input_items,
                   	gr_vector_void_star& output_items)
{
	const std::complex<float>* in = static_cast<const std::complex<float>*>(input_items[0]);
	float* out = static_cast<float*>(output_items[0]);

	std::vector<float> magnitudes(d_num_subbands, 0.0f);

	for (int i = 0; i < d_num_subbands; ++i) {
    	magnitudes[i] = std::transform_reduce(
        	in + i * d_subband_size, in + (i + 1) * d_subband_size, 0.0f,
        	std::plus<>(), [](const std::complex<float>& val) { return std::norm(val); }
    	);

    	out[i] = 10.0f * std::log10(magnitudes[i] / d_subband_size + 1e-10f);
	}

	return 1;
}

} // namespace PowerOOTcpp
} // namespace gr

