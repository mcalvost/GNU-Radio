/* -*- c++ -*- */
/*
 * Copyright 2025 you.
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

#ifndef INCLUDED_POWEROOTCPP_BANDCPP_IMPL_H
#define INCLUDED_POWEROOTCPP_BANDCPP_IMPL_H

#include <gnuradio/PowerOOTcpp/Bandcpp.h>

namespace gr {
namespace PowerOOTcpp {

class Bandcpp_impl : public Bandcpp
{
private:
	int d_num_subbands;
	int d_fft_len;
	int d_subband_size;

public:
	Bandcpp_impl(int num_subbands, int fft_len);
	~Bandcpp_impl();

	int work(int noutput_items,
         	gr_vector_const_void_star& input_items,
         	gr_vector_void_star& output_items);
};

} // namespace PowerOOTcpp
} // namespace gr

#endif /* INCLUDED_POWEROOTCPP_BANDCPP_IMPL_H */

