/* -*- c++ -*- */
/*
 * Copyright 2025 you.
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

#ifndef INCLUDED_POWEROOTCPP_BANDCPP_H
#define INCLUDED_POWEROOTCPP_BANDCPP_H

#include <gnuradio/PowerOOTcpp/api.h>
#include <gnuradio/sync_block.h>

namespace gr {
namespace PowerOOTcpp {

/*!
 * \brief <+description of block+>
 * \ingroup PowerOOTcpp
 *
 */
class POWEROOTCPP_API Bandcpp : virtual public gr::sync_block
{
public:
    typedef std::shared_ptr<Bandcpp> sptr;

    /*!
     * \brief Return a shared_ptr to a new instance of PowerOOTcpp::Bandcpp.
     *
     * To avoid accidental use of raw pointers, PowerOOTcpp::Bandcpp's
     * constructor is in a private implementation
     * class. PowerOOTcpp::Bandcpp::make is the public interface for
     * creating new instances.
     */
    static sptr make(int num_subbands, int fft_len);
};

} // namespace PowerOOTcpp
} // namespace gr

#endif /* INCLUDED_POWEROOTCPP_BANDCPP_H */
